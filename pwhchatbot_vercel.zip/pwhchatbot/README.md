# 평화누리 인사규정 챗봇 - Vercel 배포 가이드

## 📁 폴더 구조
```
pwhchatbot/
├── api/
│   └── chat.js          ← API 서버 (API 키 보관)
├── public/
│   └── index.html       ← 챗봇 화면
├── vercel.json          ← Vercel 설정
└── README.md
```

---

## 🚀 배포 순서 (15분이면 완료!)

### 1단계 - GitHub에 올리기
1. [github.com](https://github.com) 접속 → 로그인 (없으면 무료 가입)
2. 오른쪽 상단 **+** 버튼 → **New repository** 클릭
3. Repository name: `pwhchatbot` 입력 → **Create repository** 클릭
4. 화면에 나오는 **Upload files** 클릭
5. 이 폴더 전체를 드래그해서 업로드
6. **Commit changes** 클릭

### 2단계 - Vercel에 배포하기
1. [vercel.com](https://vercel.com) 접속 → **Sign up with GitHub**으로 로그인
2. **Add New Project** 클릭
3. `pwhchatbot` 저장소 선택 → **Import** 클릭
4. **Deploy** 클릭 (설정 변경 없이 그대로!)
5. 배포 완료 → `https://pwhchatbot-xxx.vercel.app` 주소 생성됨!

### 3단계 - API 키 넣기 ⭐ (제일 중요!)
1. Vercel 프로젝트 페이지에서 **Settings** 탭 클릭
2. 왼쪽 메뉴 **Environment Variables** 클릭
3. **Name**: `ANTHROPIC_API_KEY` 입력
4. **Value**: `sk-ant-...` (Anthropic 콘솔에서 발급한 키) 입력
5. **Save** 클릭
6. 상단 **Deployments** 탭 → 최근 배포 오른쪽 **...** → **Redeploy** 클릭

### 완료! 🎉
생성된 주소를 직원들에게 공유하면 바로 사용 가능해요.

---

## 💡 참고사항
- Vercel 무료 플랜: 월 100GB 대역폭, 충분해요
- API 비용: Claude Haiku 기준 질문 1만 건 약 $1~2 수준
- API 키는 Vercel 환경변수에만 저장되어 외부에 노출되지 않아요
